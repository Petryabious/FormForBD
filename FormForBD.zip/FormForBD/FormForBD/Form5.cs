﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormForBD
{
    public partial class frmProducts : Form   
    {
        private frmTable frmTable;
        public frmProducts()
        {
            InitializeComponent();
        }

        private void productBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.productBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.st14DataSet);

        }

        private void frmProducts_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "st14DataSet.PC". При необходимости она может быть перемещена или удалена.
            this.pCTableAdapter.Fill(this.st14DataSet.PC);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "st14DataSet.Laptop". При необходимости она может быть перемещена или удалена.
            this.laptopTableAdapter.Fill(this.st14DataSet.Laptop);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "st14DataSet.Product". При необходимости она может быть перемещена или удалена.
            this.productTableAdapter.Fill(this.st14DataSet.Product);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmTable = new frmTable();
            this.Hide();
            frmTable.ShowDialog();
        }
    }
}
